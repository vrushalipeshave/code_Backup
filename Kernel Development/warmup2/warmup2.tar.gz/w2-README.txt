Documentation for Warmup Assignment 2
=====================================

+-------+
| BUILD |
+-------+

Comments: make

+---------+
| GRADING |
+---------+

Basic running of the code : 100 out of 100 pts

Missing required section(s) in README file : -0
Cannot compile : -0
Compiler warnings : -0
"make clean" : -0
Segmentation faults : -0
Separate compilation : -0
Using busy-wait : -0
Handling of commandline arguments:
    1) -n : -0
    2) -lambda : -0
    3) -mu : -0
    4) -r : -0
    5) -B : -0
    6) -P : -0
Trace output :
    1) regular packets: -0
    2) dropped packets: -0
    3) removed packets: -0
    4) token arrival (dropped or not dropped): -0
Statistics output :
    1) inter-arrival time : -0
    2) service time : -0
    3) number of customers in Q1 : -0
    4) number of customers in Q2 : -0
    5) number of customers at a server : -0
    6) time in system : -0
    7) standard deviation for time in system : -0
    8) drop probability : -0
Output bad format : -0
Output wrong precision for statistics (should be 6-8 significant digits) : -0
Large service time test : -0
Large inter-arrival time test : -0
Tiny inter-arrival time test : -0
Tiny service time test : -0
Large total number of customers test : -0
Large total number of customers with high arrival rate test : -0
Dropped tokens test : -0
Cannot handle <Cntrl+C> at all (ignored or no statistics) : -0
Can handle <Cntrl+C> but statistics way off : -0
Not using condition variables and do some kind of busy-wait : -0
Synchronization check : -0
Deadlocks : -0

+------+
| BUGS |
+------+

Comments: None



