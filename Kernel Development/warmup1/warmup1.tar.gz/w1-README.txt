Documentation for Warmup Assignment 1
=====================================

+-------+
| BUILD |
+-------+

Comments: make

+---------+
| GRADING |
+---------+

(A) Doubly-linked Circular List : 40 out of 40 pts

(B.1) Sort (file) : 30 out of 30 pts
(B.2) Sort (stdin) : 30 out of 30 pts

Missing required section(s) in README file : -0
Cannot compile : -0
Compiler warnings : -0
"make clean" : -0
Segmentation faults : -0
Separate compilation : -0
Malformed input : -0
Too slow : -0
Bad commandline : -0
Bad behavior for random input : -0
Did not use My402List and My402ListElem to implement "sort" in (B) : -0

+------+
| BUGS | 
+------+

Comments: None

